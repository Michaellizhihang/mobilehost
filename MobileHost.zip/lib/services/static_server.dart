import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_static/shelf_static.dart';

typedef LogCallback = void Function(String message);

class StaticServer {
  HttpServer? _server;
  String? _root;
  int get port => _server?.port ?? 0;
  bool get isRunning => _server != null;

  Future<void> start({required String root, required int port, required LogCallback onLog}) async {
    if (_server != null) throw StateError('服务器已运行');
    final directory = Directory(root);
    if (!await directory.exists()) throw ArgumentError('网页目录不存在');
    _root = directory.path;
    final staticHandler = createStaticHandler(directory.path, defaultDocument: 'index.html', serveFilesOutsidePath: false);
    final handler = Pipeline().addMiddleware(logRequests(logger: (message, isError) => onLog(message))).addHandler((Request request) async {
      onLog('${request.method} ${request.url}');
      final uriPath = request.url.path;
      final candidate = p.normalize(p.join(directory.path, uriPath));
      if (!p.isWithin(directory.path, candidate) && candidate != directory.path) {
        return Response.forbidden('Forbidden');
      }
      var response = await staticHandler(request);
      // SPA fallback：无扩展名路径回退到 index.html。
      if (response.statusCode == 404 && !p.extension(uriPath).contains('.')) {
        response = await staticHandler(Request('GET', request.requestedUri.replace(path: '/index.html'), headers: request.headers));
      }
      return response;
    });
    _server = await shelf_io.serve(handler, InternetAddress.anyIPv4, port, shared: true);
    _server!.autoCompress = true;
    onLog('本地服务器已启动：0.0.0.0:${_server!.port}（目录：$_root）');
  }

  Future<void> stop() async {
    final server = _server;
    _server = null;
    await server?.close(force: true);
  }
}
