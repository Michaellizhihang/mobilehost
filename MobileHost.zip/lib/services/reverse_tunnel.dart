import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

typedef TunnelLog = void Function(String message);

/// MobileHost 简单消息隧道客户端。它要求 relay 实现 docs/RELAY_PROTOCOL.md，
/// 不是 LocalTunnel 的官方客户端，也不能直接连接任意 localtunnel.me 子域。
class ReverseTunnel {
  final Dio _dio = Dio();
  WebSocketChannel? _channel;
  StreamSubscription? _subscription;
  int _activeConnections = 0;
  int get activeConnections => _activeConnections;
  String? publicUrl;

  Future<void> connect({required Uri relayWs, required String token, required int localPort, required TunnelLog onLog, required void Function(int) onConnections}) async {
    final channel = WebSocketChannel.connect(relayWs);
    _channel = channel;
    await channel.ready.timeout(const Duration(seconds: 20));
    channel.sink.add(jsonEncode({'type':'register','token':token,'protocol':1,'localPort':localPort}));
    final completer = Completer<void>();
    _subscription = channel.stream.listen((dynamic raw) async {
      try {
        final msg = jsonDecode(raw as String) as Map<String, dynamic>;
        switch (msg['type']) {
          case 'ready':
            publicUrl = msg['publicUrl'] as String?;
            onLog('隧道已连接：${publicUrl ?? '(中继未返回公网 URL)'}');
            if (!completer.isCompleted) completer.complete();
            break;
          case 'request':
            _activeConnections++;
            onConnections(_activeConnections);
            unawaited(_proxyRequest(channel, msg, localPort, onLog, onConnections));
            break;
          case 'error':
            onLog('中继错误：${msg['message']}');
            if (!completer.isCompleted) completer.completeError(Exception(msg['message']));
            break;
          case 'closed':
            onLog('中继关闭连接 ${msg['id']}');
            break;
          case 'ping':
            channel.sink.add(jsonEncode({'type':'pong','at':DateTime.now().millisecondsSinceEpoch}));
            break;
        }
      } catch (e) { onLog('隧道消息处理错误：$e'); }
    }, onError: (Object e) {
      onLog('隧道连接错误：$e');
      if (!completer.isCompleted) completer.completeError(e);
    }, onDone: () {
      onLog('隧道连接已断开');
      if (!completer.isCompleted) completer.completeError(Exception('中继连接已断开'));
    });
    await completer.future.timeout(const Duration(seconds: 30));
  }

  Future<void> _proxyRequest(WebSocketChannel channel, Map<String,dynamic> msg, int port, TunnelLog log, void Function(int) count) async {
    final id = msg['id'];
    try {
      final method = (msg['method'] ?? 'GET').toString();
      final path = (msg['path'] ?? '/').toString();
      final headers = <String,dynamic>{};
      if (msg['headers'] is Map) (msg['headers'] as Map).forEach((k,v) { if (v is String) headers[k.toString()] = v; });
      final body = msg['body'] is String ? base64Decode(msg['body'] as String) : null;
      final response = await _dio.request<List<int>>('http://127.0.0.1:$port$path', data: body,
        options: Options(method: method, headers: headers, responseType: ResponseType.bytes,
          followRedirects: false, validateStatus: (_) => true,
          receiveTimeout: const Duration(seconds: 60), sendTimeout: const Duration(seconds: 60)));
      final responseHeaders = <String,String>{};
      response.headers.forEach((k,v) { if (!const {'transfer-encoding','connection','content-length'}.contains(k.toLowerCase())) responseHeaders[k] = v.join(','); });
      channel.sink.add(jsonEncode({'type':'response','id':id,'status':response.statusCode ?? 502,'headers':responseHeaders,'body':base64Encode(response.data ?? const <int>[])}));
      log('公网请求 ${method.toUpperCase()} $path → ${response.statusCode}');
    } catch (e) {
      try { channel.sink.add(jsonEncode({'type':'response','id':id,'status':502,'headers':{'content-type':'text/plain'},'body':base64Encode(utf8.encode('Bad Gateway'))})); } catch (_) {}
      log('转发失败 $id：$e');
    } finally { _activeConnections = (_activeConnections - 1).clamp(0, 1 << 30); count(_activeConnections); }
  }

  Future<void> disconnect() async {
    await _subscription?.cancel(); _subscription = null;
    await _channel?.sink.close(); _channel = null; publicUrl = null; _activeConnections = 0;
  }
}
