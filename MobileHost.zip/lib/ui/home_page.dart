import 'dart:async';
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/reverse_tunnel.dart';
import '../services/static_server.dart';

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
class _HomePageState extends State<HomePage> {
  final _server = StaticServer(); final _tunnel = ReverseTunnel();
  final _port = TextEditingController(text: '8080');
  final _relay = TextEditingController(text: 'wss://relay.example.com/tunnel');
  final _token = TextEditingController();
  final List<String> _logs = [];
  String? _webRoot; String? _selectedName; String? _publicUrl; bool _busy = false; int _connections = 0;
  void _log(String text) { if (!mounted) return; setState(() { _logs.insert(0, '[${DateTime.now().toLocal().toString().substring(11,19)}] $text'); if (_logs.length > 300) _logs.removeLast(); }); }

  Future<void> _pickProject() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip'], withData: true);
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    try {
      final bytes = file.bytes ?? (file.path != null ? await File(file.path!).readAsBytes() : null);
      if (bytes == null) throw Exception('无法读取 ZIP 文件');
      final base = await getApplicationDocumentsDirectory();
      final target = Directory(p.join(base.path, 'sites', DateTime.now().millisecondsSinceEpoch.toString()));
      await target.create(recursive: true);
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final entry in archive) {
        final outPath = p.normalize(p.join(target.path, entry.name));
        if (!p.isWithin(target.path, outPath) && outPath != target.path) continue;
        if (entry.isFile) { final out = File(outPath); await out.parent.create(recursive: true); await out.writeAsBytes(entry.content as List<int>); }
        else { await Directory(outPath).create(recursive: true); }
      }
      var root = target;
      if (!File(p.join(root.path, 'index.html')).existsSync()) {
        final children = root.listSync().whereType<Directory>().toList();
        if (children.length == 1 && File(p.join(children.first.path, 'index.html')).existsSync()) root = children.first;
      }
      if (!File(p.join(root.path, 'index.html')).existsSync()) throw Exception('压缩包根目录未找到 index.html');
      setState(() { _webRoot = root.path; _selectedName = file.name; });
      _log('已解压并选择：${file.name}');
    } catch (e) { _log('选择/解压失败：$e'); }
  }

  Future<void> _start() async {
    if (_webRoot == null) { _log('请先选择包含 index.html 的 ZIP 项目'); return; }
    final port = int.tryParse(_port.text.trim());
    final relay = Uri.tryParse(_relay.text.trim());
    if (port == null || port < 1 || port > 65535) { _log('端口必须为 1–65535'); return; }
    if (relay == null || !{'ws','wss'}.contains(relay.scheme) || relay.host.isEmpty) { _log('请输入有效的 wss:// 或 ws:// 中继 WebSocket 地址'); return; }
    setState(() => _busy = true);
    try {
      await _server.start(root: _webRoot!, port: port, onLog: _log);
      await _tunnel.connect(relayWs: relay, token: _token.text.trim(), localPort: _server.port, onLog: _log, onConnections: (n) { if (mounted) setState(() => _connections = n); });
      if (mounted) setState(() => _publicUrl = _tunnel.publicUrl);
    } catch (e) { _log('启动失败：$e'); await _tunnel.disconnect(); await _server.stop(); }
    finally { if (mounted) setState(() => _busy = false); }
  }
  Future<void> _stop() async { setState(() => _busy = true); await _tunnel.disconnect(); await _server.stop(); if (mounted) setState(() { _busy=false; _publicUrl=null; _connections=0; }); _log('服务已停止'); }
  @override void dispose() { _port.dispose(); _relay.dispose(); _token.dispose(); unawaited(_stop()); super.dispose(); }

  @override Widget build(BuildContext context) {
    final running = _server.isRunning && _publicUrl != null;
    return Scaffold(appBar: AppBar(title: const Text('MobileHost'), actions: [IconButton(tooltip:'清空日志', onPressed:()=>setState(_logs.clear), icon:const Icon(Icons.delete_outline))]),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('网页项目', style: TextStyle(fontSize:18,fontWeight:FontWeight.bold)), const SizedBox(height:10),
          OutlinedButton.icon(onPressed: _busy || running ? null : _pickProject, icon: const Icon(Icons.folder_zip_outlined), label: Text(_selectedName ?? '选择网页 ZIP 包')),
          if (_webRoot != null) Text('解压目录：$_webRoot', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height:12), TextField(controller:_port, enabled:!running, keyboardType:TextInputType.number, decoration:const InputDecoration(labelText:'本地监听端口', prefixIcon:Icon(Icons.lan_outlined), border:OutlineInputBorder())),
          const SizedBox(height:12), TextField(controller:_relay, enabled:!running, decoration:const InputDecoration(labelText:'中继 WebSocket 地址', hintText:'wss://your-relay.example/tunnel', border:OutlineInputBorder())),
          const SizedBox(height:12), TextField(controller:_token, enabled:!running, obscureText:true, decoration:const InputDecoration(labelText:'中继访问 Token（如需）', border:OutlineInputBorder())),
          const SizedBox(height:16), SizedBox(width:double.infinity,height:54, child: FilledButton.icon(onPressed:_busy?null:(running?_stop:_start), icon:_busy?const SizedBox(width:20,height:20,child:CircularProgressIndicator(strokeWidth:2)):Icon(running?Icons.stop:Icons.rocket_launch), label:Text(_busy?'正在处理…':running?'停止服务器':'启动服务器'))),
        ]))),
        Card(child: Padding(padding:const EdgeInsets.all(16), child: Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Row(children:[Icon(running?Icons.cloud_done:Icons.cloud_off,color:running?Colors.green:Colors.grey), const SizedBox(width:8), Text(running?'公网已连接':'尚未启动',style:const TextStyle(fontWeight:FontWeight.bold))]),
          const SizedBox(height:8), Text('本地地址：${_server.isRunning?'http://127.0.0.1:${_server.port}':'—'}'),
          SelectableText('公网地址：${_publicUrl ?? '—'}'),
          Text('当前转发请求：$_connections'),
          if (_publicUrl != null) Center(child:Padding(padding:const EdgeInsets.all(12),child:QrImageView(data:_publicUrl!,size:180,backgroundColor:Colors.white))),
        ]))),
        Card(child: Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Row(children:[const Icon(Icons.receipt_long),const SizedBox(width:8),const Text('连接与运行日志',style:TextStyle(fontWeight:FontWeight.bold)),const Spacer(),Text('${_logs.length} 条')]),
          const SizedBox(height:8), Container(height:260,width:double.infinity,padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.circular(8)),child:_logs.isEmpty?const Center(child:Text('启动后显示 HTTP 请求与隧道日志')):ListView.builder(reverse:true,itemCount:_logs.length,itemBuilder:(context,index)=>Padding(padding:const EdgeInsets.symmetric(vertical:3),child:SelectableText(_logs[index],style:const TextStyle(fontFamily:'monospace',fontSize:11))))),
        ]))),
        const Padding(padding:EdgeInsets.all(8),child:Text('注意：公网访问依赖兼容 MobileHost relay 协议的中继服务。LocalTunnel 公共服务不能直接填入此处。',style:TextStyle(color:Colors.orange))),
      ])));
  }
}
