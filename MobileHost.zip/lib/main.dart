import 'package:flutter/material.dart';
import 'ui/home_page.dart';

void main() => runApp(const MobileHostApp());

class MobileHostApp extends StatelessWidget {
  const MobileHostApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'MobileHost', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5267E8)), useMaterial3: true),
    home: const HomePage(),
  );
}
