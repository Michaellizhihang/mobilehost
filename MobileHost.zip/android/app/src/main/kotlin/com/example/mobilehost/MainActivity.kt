package com.example.mobilehost

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
