# MobileHost Relay Protocol (v1)

The app's tunnel transport is an application-level reverse proxy over WebSocket. It is deliberately **not** advertised as LocalTunnel-compatible. Configure the app with a relay implementing this protocol. Use `wss://` in production; `ws://` exposes the bearer token and traffic.

1. Mobile connects to `wss://relay-host/tunnel` and sends `{"type":"register","token":"...","protocol":1,"localPort":8080}`.
2. Relay authenticates the client, allocates a public URL, then sends `{"type":"ready","publicUrl":"https://name.example.net"}`.
3. For each inbound HTTP request, relay sends `{"type":"request","id":"unique","method":"GET","path":"/index.html?x=1","headers":{"accept":"*/*"},"body":"BASE64_REQUEST_BODY"}`. Body may be omitted for empty requests.
4. Client responds `{"type":"response","id":"unique","status":200,"headers":{"content-type":"text/html"},"body":"BASE64_RESPONSE_BODY"}`. Relay writes the HTTP response to the waiting public client.
5. Relay may send `{"type":"ping"}`; client returns `{"type":"pong","at":...}`. Errors use `{"type":"error","message":"..."}`.

The relay must multiplex concurrent requests by `id`, enforce request/body/time limits, remove hop-by-hop headers, and provide HTTPS on the public side. This basic v1 transports whole bodies as base64 JSON, so it is suitable for demos/small static sites, not large files or production-scale traffic. For production use binary frames/stream multiplexing and a maintained relay.

## LocalTunnel status

The public LocalTunnel client/server implementation has its own protocol and operational behavior; this app does not implement that protocol. A generic HTTP webhook cannot forward arbitrary incoming HTTP requests. To use localtunnel.me, package and invoke a compatible client runtime under its applicable license, or run the official Node client through an explicitly bundled runtime; this is outside the Dart-only transport implemented here.
